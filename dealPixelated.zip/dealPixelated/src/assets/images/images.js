import product1 from "./product1.png";
import product2 from "./product2.png";
import product3 from "./product3.png";
import product4 from "./product4.png";
import product5 from "./product5.png";
import product6 from "./product6.png";
import product7 from "./product7.png";
import product8 from "./product8.png";
import fromthread from "./fromthread.svg";
import off20 from "./off20.svg";
import logo from "./logo.svg";
import womendeals from "./woomendeals.png";
import dealhunder from "./dealhunter.svg";
import like from "./like.svg";
import comment from "./comment.svg";
import share from "./share.svg";
import searchIcon from "./searchIcon.svg";
import notification from "./notification.svg";
import user from "./user.svg";

import telephone from "./telephone.svg";
import email from "./email.svg";
import dealscore from "./dealscore.svg";
import view from "./view.svg";

import dragDrop from "./dragDrop.svg";
import messenger from "./messenger.svg";
import whatsapp from "./whatsapp.svg";
import instagram from "./instagram.svg";
import twitter from "./twitter.svg";
import deals from "./deals.svg";
import vouchers from "./vouchers.svg";
import freebies from "./freebies.svg";
import competions from "./competitions.svg";
import comments from "./comment.svg";
import hearts from "./hearts.svg";
import chatty from "./chatty.svg";
import judge from "./judge.svg";
import hunter from "./hunter.svg";
import finder from "./finder.svg";
import profilePage from "./profilePage.png";
import bigLogo from "./bigLogo.svg";
import user1 from "./user1.svg";
import user2 from "./user2.svg";
import user3 from "./user3.svg";
import user4 from "./user4.svg";

export {
  product1,
  product2,
  product3,
  product4,
  product5,
  product6,
  product7,
  product8,
  off20,
  logo,
  womendeals,
  dealhunder,
  like,
  comment,
  share,
  searchIcon,
  notification,
  user,
  telephone,
  email,
  dragDrop,
  messenger,
  whatsapp,
  instagram,
  twitter,
  deals,
  vouchers,
  freebies,
  competions,
  comments,
  hearts,
  chatty,
  judge,
  hunter,
  finder,
  profilePage,
  fromthread,
  dealscore,
  view,
  bigLogo,
  user1,
  user2,
  user3,
  user4,
};
